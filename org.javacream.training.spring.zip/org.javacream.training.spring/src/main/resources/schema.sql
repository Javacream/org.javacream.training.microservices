create table STORE (category varchar(20), item varchar(20), stock integer, primary key (category, item))
create table AUDIT (category varchar(20), message varchar(256))
